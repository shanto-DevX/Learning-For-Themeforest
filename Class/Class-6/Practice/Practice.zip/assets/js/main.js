var typed = new Typed("#typed", {
  strings: ["Web Design", "and Web Development", "Agency"],
  typeSpeed: 150,
  backSpeed: 0,
  cursorChar: "_",
  smartBackspace: true,
  loop: true,
});
